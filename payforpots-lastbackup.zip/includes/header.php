<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>PAY FOR POTS</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link rel="icon" href="assets/images/favicon.png" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no">
	<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
	<link rel="stylesheet" href="assets/css/stellarnav.min.css" />
	<link rel="stylesheet" href="assets/css/font-awesome.css">
	<link rel="stylesheet" href="assets/css/owl.carousel.min.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="stylesheet" href="assets/css/jquery.fancybox.min.css" />
	<link rel="stylesheet" href="assets/css/style.css" />
	<link rel="stylesheet" href="assets/css/substyle.css" />
	<link rel="stylesheet" href="assets/css/responsive.css" />
	<link rel="stylesheet" href="assets/css/subresponsive.css" />
</head>

<body>
	<header>
		<div class="container">
		</div>
	</header>