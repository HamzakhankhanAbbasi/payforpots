<?php include 'includes/header.php';?>

<section class="splashScreen-sec">
	<div class="logo">
		<a href="login.php">
			<img src="assets/images/logo.png" alt="logo" class="img-fluid">
		</a>
	</div>
	<img src="assets/images/vector1.png" alt="img" class="img-fluid vector1">
	<img src="assets/images/vector2.png" alt="img" class="img-fluid vector2">
</section>

<?php include 'includes/footer.php';?>
